#load the utils package
library(utils)


#unzip the archive in the current file path

unzip("Employee_Profile.zip")

#Read the content

content<-readLines(unz('Employee_Profile.zip', 'Employee.csv'))

#display the CSV file content.

print(content)
